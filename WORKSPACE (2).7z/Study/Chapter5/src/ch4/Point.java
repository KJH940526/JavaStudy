package ch4;

public class Point {
	
	
	int x;
	int y;

}
